const BloomACCRunner=require("../ABAC_Class");

exports.login = (req,res,next)=>{

};

exports.logout = (req,res,next)=>{
    
};

exports.signup = (req,res,next)=>{
    
};

exports.depolyNewSystem = (req,res,next)=>{
    console.log("hi");
    BloomACCRunner.deploy_bloomacc();
};

exports.connectExistingSystem = (req,res,next)=>{
    BloomACCRunner.connect_bloomacc();
};

exports.addEV = (req,res,next)=>{
    // console.log(req.body);
    let{
        address,
        manufacturer,
        currentLocation,
        vehicleType,
        ownerName,
        licensePlate,
        energyCapacity
    } = req.body;

    let a="";
    let info=a.concat(manufacturer,";",currentLocation,";",vehicleType,";",ownerName,";",licensePlate,";",energyCapacity)
    BloomACCRunner.sendSubject(address,info,BloomACCRunner.ev_manufacturer[BloomACCRunner.ev_manufacturer.length - 1]);
};

exports.addCS= (req,res,next)=>{
    let {address,
        plugType,
        location,
        pricingModel,
        numChargingOutlets,
        chargingPower,
        fastCharging
    } = req.body;
    
    let a="";

    let info=a.concat(plugType,";",location,";",pricingModel,";",numChargingOutlets,";",chargingPower,";",fastCharging);
    
    BloomACCRunner.sendObject(address,info,BloomACCRunner.cs_leader[BloomACCRunner.cs_leader.length - 1]);
};

exports.accessControl = (req,res,next)=>{
    
};

exports.addPolicy = (req,res,next)=>{
    
};