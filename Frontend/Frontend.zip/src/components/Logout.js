
function Logout() {
    return (
      <p>Logout</p>
    );
  }
  
  export default Logout;
  