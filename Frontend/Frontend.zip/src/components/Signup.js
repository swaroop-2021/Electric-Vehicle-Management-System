
function SignUp() {
    return (
      <p>SignUp</p>
    );
  }
  
  export default SignUp;
  