import React from 'react';

function Home() {

  const calFunc=(event)=>{
    fetch("http://"+process.env.REACT_APP_API_URL +"/deploy_new_system",
    {method:"get"})
  .then(res=>{
      return res;
  })
  }

  return (
      <div>
        <p>Home</p>
        <button onClick={calFunc}>Click here</button>
      </div>
    );
  }
  
  export default Home;
  