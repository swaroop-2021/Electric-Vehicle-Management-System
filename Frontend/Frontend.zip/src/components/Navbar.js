import React from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import { Navbar, Nav } from 'react-bootstrap';
import {LinkContainer} from 'react-router-bootstrap'

function NavigationBar() {
    return (
        <div>
            <Navbar bg="light" expand="lg">
                <LinkContainer to="/">
                    <Navbar.Brand>ABAC System</Navbar.Brand>
                </LinkContainer>
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="mr-auto">
                        <LinkContainer to="/login"> 
                            <Nav.Link>Login</Nav.Link> 
                        </LinkContainer>
                        <LinkContainer to="/signup"> 
                            <Nav.Link>SignUp</Nav.Link> 
                        </LinkContainer>
                    </Nav>
                </Navbar.Collapse>
            </Navbar>
        </div>
        );
  }
  
export default NavigationBar;
  